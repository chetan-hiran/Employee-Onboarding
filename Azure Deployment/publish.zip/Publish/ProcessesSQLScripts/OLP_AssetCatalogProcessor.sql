/*
* This script fetches the assets per paths that need to be corrected
* If an asset per path is active while the corresponding asset or path is inactive, it has an inconsistent status and it should be deactivated
* If an asset per path is inactive while both the corresponding asset and path are active, it has an inconsistent status and it should be activated
*/


SELECT [APP].olp_assetperpathid
	 , [APP].statecode
	 , [APP].statuscode
	 , [APP].olp_path
	 , [APP].olp_assetcatalog
  FROM olp_assetperpath		[APP]
  JOIN wwlsvy_certification [AC]	ON [APP].olp_AssetCatalog = [AC].wwlsvy_certificationid AND [AC].olp_application = 883550001
  JOIN olp_paths			[P]		ON [APP].olp_Path = [P].olp_pathsid
 WHERE [APP].StatusCode <> 883550000
   AND ( ([APP].StateCode = 0 AND ([AC].StateCode <> 0 OR [P].StateCode <> 0))
		OR ([APP].StateCode <> 0 AND [AC].StateCode = 0 AND [P].StateCode = 0)
		)

