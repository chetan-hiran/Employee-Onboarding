
DECLARE @LearnerPositionEntryDate AS DATE;
SELECT @LearnerPositionEntryDate = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_LPPProcessor_LearnerPositionEntryDate'
SET @LearnerPositionEntryDate = ISNULL ( @LearnerPositionEntryDate, '01/01/1753')

DECLARE @Organization AS NVARCHAR(MAX) = NULL
SELECT @Organization = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_LPPProcessor_Organizations'

DECLARE @AreaSpecificFeatureFlag AS BIT = NULL
SELECT @AreaSpecificFeatureFlag = CASE WHEN wwlsvy_value = 'ON' THEN 1 ELSE 0 END FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'Area'

declare @areaid uniqueidentifier = '{areaid}'


SELECT	DISTINCT ISNULL([ExpectedAPL].emailaddress1, [ExistingAPL].DeactivateEmailAddress)	AS EmailAddress
		,ISNULL([ExpectedAPL].contactid, [ExistingAPL].wwlsvy_contact)						AS ContactId
		,[ExpectedAPL].fullname																AS FullName
		,[ExpectedAPL].olp_assetcatalogname													AS olp_assetcatalogname
		,[ExpectedAPL].olp_assetcatalog														AS olp_assetcatalog
		,CASE 
			WHEN [ExistingAPL].wwlsvy_contact IS NULL
				AND [ExpectedAPL].contactid IS NOT NULL
				THEN 'Create'
			WHEN [ExistingAPL].wwlsvy_contact IS NOT NULL
				AND [ExpectedAPL].contactid IS NULL
				AND [ExistingAPL].statecode = 0
				THEN 'Deactivate'
			WHEN [ExistingAPL].wwlsvy_contact IS NOT NULL
				AND [ExpectedAPL].contactid IS NOT NULL
				AND [ExistingAPL].statecode = 1
				THEN 'Activate'
			END 																			AS [Action]
		,[ExistingAPL].wwlsvy_certificationcompletionid 									AS ExistingAPLId
		,[ExistingAPL].statecode															AS ExistingAPLStateCode
		,[ExistingAPL].olp_assetid															AS ExistingAssetCatalog
  FROM
  (
		SELECT	DISTINCT [C].emailaddress1			AS emailaddress1
				,[C].contactid						AS contactid
				,[C].fullname						AS FullName
				,[APP].olp_assetcatalogname			AS olp_assetcatalogname
				,[APP].olp_assetcatalog				AS olp_assetcatalog
				,[PP].wwlsvy_qualifiercriteriaid	AS PPID
		  FROM contact					AS [C]
		  JOIN olp_learnerroles			AS [LPP]
			ON [LPP].olp_learnerid = [C].contactid 
		   AND [LPP].statecode = 0
		  JOIN wwlsvy_qualifiercriteria	AS [PP]
			ON [LPP].olp_programparameter = [PP].wwlsvy_qualifiercriteriaid
		   AND [PP].statecode = 0
		   AND [PP].statuscode = 1 --'Live'
		   AND [PP].olp_applicationtype = 883550000 --'OLP'
		  JOIN olp_pathsperrole			AS [PPP]
			ON [PPP].olp_rolecode = [PP].wwlsvy_qualifiercriteriaid
		   AND [PPP].statecode = 0
		  JOIN olp_paths				AS [PATHS] 
			ON [PPP].olp_path = [PATHS].olp_pathsid
		   AND [PATHS].statecode = 0
		  JOIN olp_assetperpath			AS [APP]
			ON [APP].olp_path = [PATHS].olp_pathsid
		   AND [APP].statecode = 0
		  JOIN wwlsvy_certification		AS [AC] 
			ON [AC].wwlsvy_certificationid = [APP].olp_assetcatalog
		   AND [AC].statecode = 0
		 WHERE CHARINDEX(UPPER([C].olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), [C].olp_reportstoemaillevel1)) > 0
		   AND [C].wwlsvy_positionentrydate >= @LearnerPositionEntryDate
		   AND [C].olp_area = @areaid

		 UNION
		
		SELECT	DISTINCT [C].emailaddress1	AS emailaddress1
				,[C].contactid					AS contactid
				,[C].fullname					AS FullName
				,[APP].olp_assetcatalogname		AS olp_assetcatalogname
				,[APP].olp_assetcatalog			AS olp_assetcatalog
				,NULL							AS PPID
		  FROM contact			AS [C]
		  JOIN olp_paths		AS [PATHS]
			ON [PATHS].wwlsvy_area = [C].olp_area
		   AND [PATHS].statecode = 0
		  JOIN olp_assetperpath	AS [APP] 
			ON [PATHS].olp_pathsid = [APP].olp_path
		   AND [APP].statecode = 0
		  JOIN olp_learnerroles AS [LPP] 
			ON [LPP].olp_learnerid = [C].contactid
		   AND [LPP].statecode = 0
		 WHERE @AreaSpecificFeatureFlag = 1
		   AND CHARINDEX(UPPER([C].olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), [C].olp_reportstoemaillevel1)) > 0
		   AND [C].wwlsvy_positionentrydate >= @LearnerPositionEntryDate
		   AND [LPP].olp_programparameter IS NOT NULL
		   AND [C].olp_area = @areaid

	)	AS [ExpectedAPL]
FULL OUTER JOIN 
	(
		SELECT	[APL].wwlsvy_certificationcompletionid
				,[APL].wwlsvy_contact
				,[APL].olp_assetid
				,[APL].olp_programparameter
				,[APL].statecode
				,[C].emailaddress1 AS DeactivateEmailAddress
		  FROM wwlsvy_certificationcompletion	AS [APL]
		  JOIN wwlsvy_certification				AS [AC]
			ON [AC].wwlsvy_certificationid = [APL].olp_assetid
		  JOIN contact							AS [C]
			ON [C].contactid = [APL].wwlsvy_contact
		   AND [C].olp_area = @areaid
		 WHERE CHARINDEX(UPPER([C].olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), [C].olp_reportstoemaillevel1)) > 0
		   AND [C].wwlsvy_positionentrydate >= @LearnerPositionEntryDate
		   AND [AC].olp_application = 883550001 -- OLP
			
	)	AS [ExistingAPL] 
	ON [ExistingAPL].wwlsvy_contact = [ExpectedAPL].contactid
   AND [ExistingAPL].olp_assetid = [ExpectedAPL].olp_assetcatalog
 WHERE 1=1
   AND(
		([ExistingAPL].wwlsvy_contact IS NULL AND [ExpectedAPL].contactid IS NOT NULL) --'Create'
		OR ([ExistingAPL].wwlsvy_contact IS NOT NULL AND [ExpectedAPL].contactid IS NULL AND [ExistingAPL].statecode = 0) -- 'Deactivate'		
		OR ([ExistingAPL].wwlsvy_contact IS NOT NULL AND [ExpectedAPL].contactid IS NOT NULL AND [ExistingAPL].statecode = 1) -- 'Activate'
	)

