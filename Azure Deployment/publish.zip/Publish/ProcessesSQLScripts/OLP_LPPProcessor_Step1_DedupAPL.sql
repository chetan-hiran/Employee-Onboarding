/*
* This script fetches the duplicate assets per learners that should be deleted
* The duplication is decided based on the key: Asset, Learner and Program Parameter
* Only in-active, not-completed records will be deleted. Otherwise, manual correction is required
*/


DECLARE @Organization AS NVARCHAR(MAX) = NULL
SELECT @Organization = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_LPPProcessor_Organizations'


SELECT	[APL].wwlsvy_certificationcompletionid
		,[APL].wwlsvy_contact
		,[APL].olp_assetid 
		,[APL].olp_programparameter
		,[APL].createdon
FROM wwlsvy_certificationcompletion AS [APL]
JOIN (	SELECT wwlsvy_contact, olp_assetid ,olp_programparameter, MIN(createdon) MinCreatedOnDate
		  FROM wwlsvy_certificationcompletion
		 GROUP BY wwlsvy_contact, olp_assetid, olp_programparameter
		HAVING COUNT(1) > 1
	  )								AS [DuplicateAPL]
  ON [APL].wwlsvy_contact = [DuplicateAPL].wwlsvy_contact
 AND [APL].olp_assetid = [DuplicateAPL].olp_assetid
 AND [APL].olp_programparameter = [DuplicateAPL].olp_programparameter
 AND [APL].olp_completed <> '883550000'
 AND [APL].olp_bookmarked = '0'
 AND [APL].olp_rating IS NULL
 AND [APL].createdon <> [DuplicateAPL].MinCreatedOnDate AND [APL].statecode = 1
JOIN Contact AS [C]
			 ON [C].contactid = [APL].wwlsvy_contact
JOIN wwlsvy_qualifiercriteria AS [PP] 
			 ON [APL].olp_programparameter = [PP].wwlsvy_qualifiercriteriaid
			AND [PP].olp_applicationtype = 883550000
WHERE CHARINDEX(UPPER([C].olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), [C].olp_reportstoemaillevel1)) > 0

