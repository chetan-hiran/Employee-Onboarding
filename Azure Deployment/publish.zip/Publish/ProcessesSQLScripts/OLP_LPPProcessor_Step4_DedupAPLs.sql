
declare @areaid uniqueidentifier = '{areaid}' -- '52853F90-AAEC-EC11-BB3D-0022482EA91E' = US

SELECT	*
FROM 
(
	SELECT	[APL].wwlsvy_certificationcompletionid -- 22434
			,[APL].olp_assetid
			,[APL].wwlsvy_contact
			,ROW_NUMBER() OVER (
					PARTITION BY [APL].olp_assetid, [APL].wwlsvy_contact
					ORDER BY [APL].statecode ASC, [APL].olp_completed ASC, [APL].olp_bookmarked DESC, [APL].olp_rating DESC
				) RowNumber
	  FROM wwlsvy_certificationcompletion [APL] (NOLOCK)
	 WHERE EXISTS
	 (
		SELECT	COUNT(1)
				,[DuplicateAPL].olp_assetid
				,[DuplicateAPL].wwlsvy_contact
		  FROM wwlsvy_certificationcompletion	[DuplicateAPL] (NOLOCK)
		  JOIN contact							[C] (NOLOCK)
			ON [DuplicateAPL].wwlsvy_contact = [C].ContactId
		   AND [C].olp_area = @areaid
		 WHERE [DuplicateAPL].owneridname = 'OLP'
		   AND [APL].olp_assetid = [DuplicateAPL].olp_assetid
		   AND [APL].wwlsvy_contact = [DuplicateAPL].wwlsvy_contact
		 GROUP BY [DuplicateAPL].olp_assetid, [DuplicateAPL].wwlsvy_contact
		HAVING COUNT(1) > 1
	 )
 ) [DuplicatesOrdered]
 WHERE [DuplicatesOrdered].RowNumber > 1



