
DECLARE @LearnerPositionEntryDate AS DATE;
SELECT @LearnerPositionEntryDate = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_PPProcessor_LearnerPositionEntryDate'
SET @LearnerPositionEntryDate = ISNULL ( @LearnerPositionEntryDate, '01/01/1753')


DECLARE @Organization AS NVARCHAR(MAX) = NULL
SELECT @Organization = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_PPProcessor_Organizations'



SELECT	[ExpectedLPP].contactid					AS ExpectedContactId
		,[ExpectedLPP].fullname					AS ExpectedFullName
		,[ExpectedLPP].emailaddress1			AS ExpectedEmailAddress1
		,[ExpectedLPP].PostionEntryDate			AS ExepctedPositionEntryDate
		,[ExpectedLPP].ExpectedPP				AS ExpectedPP
		,[ExpectedLPP].ExpectedPPId				AS ExpectedPPId
		,[CurrentLPP].contactid					AS CurrentContactId
		,[CurrentLPP].olp_reportstoemaillevel1	AS CurrentContactReportsToEmailLevel1
		,[CurrentLPP].CurrentPP					AS CurrentPP
		,[CurrentLPP].CurrentPPId				AS CurrentPPId
		,[CurrentLPP].CurrentLPPId				AS CurrentLPPId
		,[CurrentLPP].AutoAssign				AS AutoAssign
		,CASE	WHEN [ExpectedLPP].ExpectedPP = [CurrentLPP].CurrentPP 
				THEN 'Match' 
				ELSE 'Mismatch' END				AS MatchRES
 FROM
	(
	SELECT	[C].contactid
			,[C].fullname
			,[C].emailaddress1
			,[C].wwlsvy_positionentrydate AS PostionEntryDate
			,[PP].wwlsvy_name AS ExpectedPP
			,[PP].wwlsvy_qualifiercriteriaid AS ExpectedPPId, 
			Row_Number() OVER(PARTITION BY [C].contactid ORDER BY [PP].wwlsvy_name) AS RowNum
	FROM	contact						[C]
	JOIN	wwlsvy_qualifiercriteria	[PP]
	  ON	ISNULL([C].olp_rolesummary,'') = ISNULL([PP].wwlsvy_standardtitle,'')
	 AND	ISNULL([C].wwlsvy_qualifier1,'') = ISNULL([PP].wwlsvy_qualifier1,'')
	 AND	ISNULL([C].wwlsvy_qualifier2,'') = ISNULL([PP].wwlsvy_qualifier2,'')
	 AND	ISNULL([C].wwlsvy_orgdetail,'') = ISNULL([PP].wwlsvy_org,'')
	 AND	ISNULL(CAST([C].olp_persona AS NVARCHAR(40)),'') = ISNULL(CAST([PP].olp_persona AS NVARCHAR(40)),'')
   WHERE	[C].StateCode = 0
	 AND	[PP].statecode = 0
	 AND	[PP].statuscode = 1
	 AND	[PP].olp_applicationtype = 883550000 
	 AND	[C].wwlsvy_positionentrydate >= @LearnerPositionEntryDate
	 AND	CHARINDEX(UPPER([C].olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), [C].olp_reportstoemaillevel1)) > 0
	)								AS [ExpectedLPP]
FULL OUTER JOIN  
	( 
	SELECT	[C].contactid AS contactid
			,[C].olp_reportstoemaillevel1 AS olp_reportstoemaillevel1
			,[LPP].olp_programparametername AS CurrentPP
			,[LPP].olp_programparameter AS CurrentPPId
			,[LPP].wwlsvy_autoassigned AS AutoAssign 
			,[LPP].olp_learnerrolesid AS CurrentLPPId
	  FROM contact					AS [C]
	  JOIN olp_learnerroles	AS [LPP]        
		ON [C].contactid= [LPP].olp_learnerid
	   AND [LPP].statecode = 0 
	 WHERE [C].StateCode = 0
	   AND [C].wwlsvy_positionentrydate >= @LearnerPositionEntryDate
	   AND CHARINDEX(UPPER([C].olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), [C].olp_reportstoemaillevel1)) > 0
	)								AS [CurrentLPP] 
   ON [ExpectedLPP].contactid = [CurrentLPP].contactid
WHERE (ROWNum IS NULL OR ROWNum = 1)
    AND ISNULL([ExpectedLPP].ExpectedPP, '') <> ISNULL([CurrentLPP].CurrentPP, '')
	AND ( [CurrentLPP].AutoAssign = 'True' OR [CurrentLPP].AutoAssign IS NULL)
ORDER BY PostionEntryDate DESC


