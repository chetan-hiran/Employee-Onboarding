/*
* This script fetches the learners that have multiple active program parameters. Only one program parameter shall be assigned to the learner at any time
* Thes records returning from this script should be deactivated. This is a pre-requisite for the Program Parameter Processor in OLP Automation before 
* trying to correct the LPPs
*/


DECLARE @LearnerPositionEntryDate AS DATE;
SELECT @LearnerPositionEntryDate = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_PPProcessor_LearnerPositionEntryDate'
SET @LearnerPositionEntryDate = ISNULL ( @LearnerPositionEntryDate, '01/01/1753')

DECLARE @Organization AS NVARCHAR(MAX) = NULL
SELECT @Organization = wwlsvy_value FROM [dbo].[wwlsvy_systemconfiguration] WHERE wwlsvy_name = 'OLP_PPProcessor_Organizations'


SELECT OUTERLPP.olp_learnerrolesid, OUTERLPP.olp_learnerid, OUTERLPP.olp_programparameter, OUTERLPP.olp_programparametername
FROM 
(
SELECT	COUNT(1) AS PPCount, C.contactid AS olp_learnerid, STRING_AGG(ISNULL(LPP.olp_programparametername, ''), ',') AS DuplicateProgramParameter
  FROM	olp_learnerroles LPP
  JOIN	contact C ON C.contactid = LPP.olp_learnerid
 WHERE	CHARINDEX(UPPER(C.olp_reportstoemaillevel1), ISNULL(UPPER(@Organization), C.olp_reportstoemaillevel1)) > 0
   AND	C.StateCode = 0
   AND	LPP.statecode = 0
   AND	C.wwlsvy_positionentrydate >= @LearnerPositionEntryDate
group by  C.contactid
having COUNT(1) > 1
) DuplicateLPPGroupedByContact
JOIN	olp_learnerroles OUTERLPP 
  ON	OUTERLPP.olp_learnerid = DuplicateLPPGroupedByContact.olp_learnerid
WHERE	OUTERLPP.wwlsvy_autoassigned  = 'True'
   AND	OUTERLPP.statecode = 0
ORDER BY OUTERLPP.olp_learnerid


