
SELECT	[ActiveAPL].wwlsvy_certificationcompletionid		[ActiveAPLId]
		,[InActiveAPL].olp_completed						[InActiveAPLCompleted]
		,[InActiveAPL].wwlsvy_completeddate					[InActiveAPLCompletedDate]
		,[InActiveAPL].olp_bookmarked						[InActiveAPLBookmarked]
		,[InActiveAPL].olp_rating							[InActiveAPLRating]
  FROM	wwlsvy_certificationcompletion [ActiveAPL]
  JOIN	wwlsvy_certificationcompletion [InActiveAPL]
	ON	[ActiveAPL].wwlsvy_contact = [InActiveAPL].wwlsvy_contact
   AND	[ActiveAPL].olp_assetid = [InActiveAPL].olp_assetid
   AND	[ActiveAPL].statecode = 0
   AND	[InActiveAPL].statecode = 1 
   AND ( ([ActiveAPL].olp_completed = 883550001 AND [InActiveAPL].olp_completed = 883550000)
		OR ([ActiveAPL].olp_bookmarked = 0 AND [InActiveAPL].olp_bookmarked = 1) 
		OR ([ActiveAPL].olp_rating IS NULL AND [InActiveAPL].olp_rating IS NOT NULL) )
   AND [ActiveAPL].ownerid = '6BF65484-3A1A-ED11-B83E-0022480A0B2E' -- OLP owner



--SELECT	[ActiveAPL].wwlsvy_certificationcompletionid		[ActiveAPLId]
--		,[ActiveAPL].wwlsvy_contact							[ActiveAPLContactId]
--		,[ActiveAPL].wwlsvy_contactname						[ActiveAPLContactName]
--		,[ActiveAPL].olp_assetid							[ActiveAPLAssetId]
--		,[ActiveAPL].olp_assetidname						[ActiveAPLAssetName]
--		,[ActiveAPL].olp_programparameter					[ActiveAPLPPId]
--		,[ActiveAPL].olp_programparametername				[ActiveAPLPPName]
--		,[ActiveAPL].olp_completed							[ActiveAPLCompleted]
--		,[ActiveAPL].wwlsvy_completeddate					[ActiveAPLCompletedDate]
--		,[ActiveAPL].olp_bookmarked							[ActiveAPLBookmarked]
--		,[ActiveAPL].olp_rating								[ActiveAPLRating]
--		,[InActiveAPL].wwlsvy_certificationcompletionid		[InActiveAPLId]
--		,[InActiveAPL].wwlsvy_contact						[InActiveAPLContactId]
--		,[InActiveAPL].wwlsvy_contactname					[InActiveAPLContactName]
--		,[InActiveAPL].olp_assetid							[InActiveAPLAssetId]
--		,[InActiveAPL].olp_assetidname						[InActiveAPLAssetName]
--		,[InActiveAPL].olp_programparameter					[InActiveAPLPPId]
--		,[InActiveAPL].olp_programparametername				[InActiveAPLPPName]
--		,[InActiveAPL].olp_completed						[InActiveAPLCompleted]
--		,[InActiveAPL].wwlsvy_completeddate					[InActiveAPLCompletedDate]
--		,[InActiveAPL].olp_bookmarked						[InActiveAPLBookmarked]
--		,[InActiveAPL].olp_rating							[InActiveAPLRating]
--  FROM	wwlsvy_certificationcompletion [ActiveAPL]			
--  JOIN	wwlsvy_certificationcompletion [InActiveAPL]
--	ON	[ActiveAPL].wwlsvy_contact = [InActiveAPL].wwlsvy_contact
--   AND	[ActiveAPL].olp_assetid = [InActiveAPL].olp_assetid
--   AND	[ActiveAPL].statecode = 0
--   AND	[InActiveAPL].statecode = 1 
--  AND ( ([ActiveAPL].olp_completed = 883550001 AND [InActiveAPL].olp_completed = 883550000)
--		OR ([ActiveAPL].olp_bookmarked = 0 AND [InActiveAPL].olp_bookmarked = 1) 
--		OR ([ActiveAPL].olp_rating IS NULL AND [InActiveAPL].olp_rating IS NOT NULL) )
--   AND [ActiveAPL].ownerid = '6BF65484-3A1A-ED11-B83E-0022480A0B2E' -- OLP owner

